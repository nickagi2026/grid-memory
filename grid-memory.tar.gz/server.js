#!/usr/bin/env node
/**
 * shared-memory-grid/server.js
 *
 * HTTP wrapper for The Grid. Exposes the store.js API as REST endpoints.
 *
 * Usage:
 *   node server.js                    # listens on 0.0.0.0:8080
 *   PORT=9090 node server.js         # custom port
 *   GRID_STORE_DIR=/data node server.js  # custom data directory
 *
 * Endpoints:
 *   POST /write   { agent_id, type, content, tags, ttl_seconds, session_id, parent_entry }
 *   GET  /query   ?tags=a,b&agents=x&type=y&max=20
 *   POST /prune
 *   GET  /inject  ?context=message
 *   GET  /info
 *   DELETE /forget/:id
 *   GET  /health
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const { Grid } = require('./reference/store.js');
const openaiProxy = require('./openai-proxy.js');

const PORT = parseInt(process.env.PORT, 10) || 8080;
const HOST = process.env.HOST || '0.0.0.0';

const grid = new Grid();

// ─── JSON body parser ──────────────────────────────────────────────────────────

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => (body += chunk));
    req.on('end', () => {
      if (!body) return resolve({});
      try {
        resolve(JSON.parse(body));
      } catch (e) {
        reject(new Error('Invalid JSON'));
      }
    });
    req.on('error', reject);
  });
}

// ─── URL query parser ──────────────────────────────────────────────────────────

function parseQuery(url) {
  const idx = url.indexOf('?');
  if (idx === -1) return {};
  const qs = url.slice(idx + 1);
  const params = {};
  for (const part of qs.split('&')) {
    const [k, v] = part.split('=').map(decodeURIComponent);
    if (k) params[k] = v;
  }
  return params;
}

// ─── Response helpers ──────────────────────────────────────────────────────────

function json(res, data, status = 200) {
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*'
  });
  res.end(JSON.stringify(data, null, 2));
}

function error(res, message, status = 400, code = 'INVALID_PARAMETER') {
  json(res, { error: message, code }, status);
}

// ─── Router ────────────────────────────────────────────────────────────────────

async function handle(req, res) {
  // CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
    return res.end();
  }

  const method = req.method;
  const url = req.url.split('?')[0];
  const query = parseQuery(req.url);

  try {
    // GET /health
    if (method === 'GET' && url === '/health') {
      const info = await grid.info();
      return json(res, {
        status: 'ok',
        store: {
          total_entries: info.total_entries,
          alive_entries: info.alive_entries,
          store_size_kb: info.store_size_kb
        },
        version: '1.0.0'
      });
    }

    // GET /info
    if (method === 'GET' && url === '/info') {
      const info = await grid.info();
      return json(res, info);
    }

    // POST /query (complex queries with JSON body, avoids URL length limits)
    if (method === 'POST' && url === '/query') {
      const body = await parseBody(req);
      const result = await grid.read({
        tags: body.tags || [],
        agents: body.agents || [],
        type: body.type || null,
        types: body.types || [],
        max: body.max || undefined,
        since: body.since || null,
        before: body.before || null,
        tagMode: body.tagMode || 'OR',
        parent_entry: body.parent_entry || null
      });
      return json(res, result);
    }

    // POST /write
    if (method === 'POST' && url === '/write') {
      const body = await parseBody(req);
      if (!body.agent_id) return error(res, 'agent_id is required');
      if (!body.content) return error(res, 'content is required');
      if (body.type && !['decision','fact','task_status','artifact_ref','handoff','question','observation','blocker','state_update'].includes(body.type)) {
        return error(res, `Invalid type "${body.type}". Valid types: decision, fact, task_status, artifact_ref, handoff, question, observation, blocker, state_update`);
      }
      const result = await grid.write({
        agent_id: body.agent_id,
        type: body.type || 'observation',
        tags: body.tags || [],
        content: body.content,
        ttl_seconds: body.ttl_seconds,
        session_id: body.session_id,
        parent_entry: body.parent_entry
      });
      return json(res, result, 201);
    }

    // GET /query
    if (method === 'GET' && url === '/query') {
      const result = await grid.read({
        tags: query.tags ? query.tags.split(',').filter(Boolean) : [],
        agents: query.agents ? query.agents.split(',').filter(Boolean) : [],
        type: query.type || null,
        types: query.types ? query.types.split(',').filter(Boolean) : [],
        max: query.max ? parseInt(query.max, 10) : undefined,
        since: query.since || null,
        before: query.before || null,
        tagMode: query.tagMode || 'OR'
      });
      return json(res, result);
    }

    // POST /inject (alternative to GET, supports larger context hints)
    if (method === 'POST' && url === '/inject') {
      const body = await parseBody(req);
      const result = await grid.inject(body.context || '');
      return json(res, result);
    }

    // GET /inject
    if (method === 'GET' && url === '/inject') {
      const result = await grid.inject(query.context || '');
      return json(res, result);
    }

    // POST /prune
    if (method === 'POST' && url === '/prune') {
      const result = await grid.prune();
      return json(res, result);
    }

    // DELETE /forget/:id
    if (method === 'DELETE' && url.startsWith('/forget/')) {
      const id = url.slice(8); // '/forget/'.length
      if (!id) return error(res, 'Entry ID is required');
      const result = await grid.forget(id);
      if (!result.found) return error(res, result.message, 404, 'NOT_FOUND');
      return json(res, result);
    }

    // OpenAI-compatible proxy routes
    if (url.startsWith('/v1/')) {
      return openaiProxy.route(req, res);
    }

    // Serve dashboard static files
    if (url.startsWith('/dashboard/') || url === '/dashboard') {
      let filePath = url === '/dashboard' ? '/dashboard/index.html' : url;
      const fullPath = path.join(__dirname, 'dashboard', filePath.replace('/dashboard/', ''));
      if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
        const ext = path.extname(fullPath).toLowerCase();
        const contentTypes = {
          '.html': 'text/html',
          '.js': 'application/javascript',
          '.css': 'text/css',
          '.json': 'application/json',
          '.png': 'image/png',
          '.svg': 'image/svg+xml',
          '.ico': 'image/x-icon',
        };
        const contentType = contentTypes[ext] || 'application/octet-stream';
        const content = fs.readFileSync(fullPath);
        res.writeHead(200, { 'Content-Type': contentType });
        return res.end(content);
      }
      // Fall through to 404 if file doesn't exist
    }
    error(res, `Not found: ${method} ${url}`, 404, 'NOT_FOUND');

  } catch (err) {
    console.error(`[Grid Server] Error: ${err.message}`);
    error(res, err.message, 500, 'INTERNAL_ERROR');
  }
}

// ─── Start ─────────────────────────────────────────────────────────────────────

// Share grid instance with the OpenAI proxy
openaiProxy.setGrid(grid);

const server = http.createServer(handle);

server.listen(PORT, HOST, () => {
  console.log(`═══ Grid Memory Server ═══`);
  console.log(`Listening on http://${HOST}:${PORT}`);
  console.log(`Endpoints:`);
  console.log(`  POST /write           — Write an entry`);
  console.log(`  GET|POST /query       — Query entries`);
  console.log(`  GET|POST /inject      — Get context injection block`);
  console.log(`  POST /prune           — Remove expired entries`);
  console.log(`  GET  /info            — Store stats`);
  console.log(`  DELETE /forget/       — Remove a specific entry`);
  console.log(`  GET  /health          — Health check`);
  console.log(`  GET  /v1/models       — List models (OpenAI-compat)`);
  console.log(`  POST /v1/chat/completions — Chat completions (OpenAI-compat)`);
  if (process.env.GRID_UPSTREAM_API_KEY) {
    const keyPreview = process.env.GRID_UPSTREAM_API_KEY.slice(0, 4) + '...' + process.env.GRID_UPSTREAM_API_KEY.slice(-4);
    console.log(`Upstream: ${process.env.GRID_UPSTREAM_URL || 'https://api.openai.com'} (key: ${keyPreview})`);
  } else {
    console.log(`Upstream: NOT CONFIGURED — set GRID_UPSTREAM_API_KEY. Returns debug responses.`);
  }
  console.log(`Data dir: ${process.env.GRID_STORE_DIR || '(default)'}`);
  console.log(`═══════════════════════════════`);
});

#!/usr/bin/env node
/**
 * shared-memory-grid/store.js
 *
 * Reference implementation of The Grid — a shared persistent memory store
 * for multi-agent teams. Append-only writes, relevance-weighted reads,
 * TTL-based pruning, and context injection.
 *
 * Architecture:
 *   - File-based JSON store at ~/.openclaw/workspace/skills/shared-memory-grid/data/store.json
 *   - Tags indexed in data/index.json for fast retrieval
 *   - Append-only writes: never modifies existing entries
 *   - Relevance scoring: tag match > type match > recency
 *
 * Usage (CLI):
 *   node store.js write --agent main --type decision --tags project:alpha --ttl 86400 --content "..."
 *   node store.js read --tags project:alpha --max 10
 *   node store.js inject --context "user is asking about database"
 *   node store.js prune
 *   node store.js info
 *   node store.js forget --id grid_xxxxx
 *
 * Usage (module):
 *   const { Grid } = require('./store.js');
 *   const grid = new Grid();
 *   await grid.write({ agent_id: "main", type: "decision", ... });
 *   const results = await grid.read({ tags: ["project:alpha"] });
 *   const ctx = await grid.inject("agent just spawned");
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ─── Configuration ────────────────────────────────────────────────────────────

const CONFIG = {
  STORE_DIR: process.env.GRID_STORE_DIR || path.join(
    process.env.HOME || process.env.USERPROFILE || '/tmp',
    '.openclaw', 'workspace', 'skills', 'shared-memory-grid', 'data'
  ),
  STORE_FILE: 'store.json',
  INDEX_FILE: 'index.json',
  MAX_INJECT_SIZE: 4096,            // max bytes for context injection block
  DEFAULT_MAX_RESULTS: 10,
  ABSOLUTE_MAX_RESULTS: 50,
  MAX_STORE_SIZE_MB: 10,
  COMPRESSION_THRESHOLD_MB: 5,
  // Default TTLs by type (seconds)
  DEFAULT_TTLS: {
    decision: 86400,         // 24 hours
    fact: 86400,             // 24 hours
    task_status: 3600,       // 1 hour
    artifact_ref: 604800,    // 7 days
    handoff: 3600,           // 1 hour
    question: 43200,         // 12 hours
    observation: 86400,      // 24 hours
    blocker: 86400,          // 24 hours
    state_update: 3600       // 1 hour
  },
  VALID_TYPES: [
    'decision', 'fact', 'task_status', 'artifact_ref',
    'handoff', 'question', 'observation', 'blocker', 'state_update'
  ]
};

const STORE_PATH = () => path.join(CONFIG.STORE_DIR, CONFIG.STORE_FILE);
const INDEX_PATH = () => path.join(CONFIG.STORE_DIR, CONFIG.INDEX_FILE);

// ─── Utility ──────────────────────────────────────────────────────────────────

function generateId() {
  const date = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const random = crypto.randomBytes(6).toString('hex');
  return `grid_${date}_${random}`;
}

function now() {
  return new Date().toISOString();
}

function nowUnix() {
  return Math.floor(Date.now() / 1000);
}

function assert(condition, message) {
  if (!condition) {
    throw new Error(`[Grid] ${message}`);
  }
}

// ─── The Grid Core ────────────────────────────────────────────────────────────

class Grid {
  constructor(options = {}) {
    this.config = { ...CONFIG, ...options };
    this._store = null;
    this._index = null;
    this._ensureDir();
  }

  // ── Initialization ──

  _ensureDir() {
    if (!fs.existsSync(this.config.STORE_DIR)) {
      fs.mkdirSync(this.config.STORE_DIR, { recursive: true });
    }
  }

  _loadStore() {
    const sp = STORE_PATH();
    try {
      if (fs.existsSync(sp)) {
        const raw = fs.readFileSync(sp, 'utf-8');
        this._store = JSON.parse(raw);
        // Migrate v0 → v1 if needed
        if (!Array.isArray(this._store.entries)) {
          // Old format: top-level array
          this._store = { version: 1, created_at: now(), entries: this._store };
        }
      } else {
        this._store = { version: 1, created_at: now(), entries: [] };
      }
    } catch (err) {
      // Corruption recovery
      const backup = `${sp}.corrupt.${nowUnix()}`;
      console.error(`[Grid] Store corruption detected. Backing up to ${backup}`);
      if (fs.existsSync(sp)) {
        fs.renameSync(sp, backup);
      }
      this._store = { version: 1, created_at: now(), entries: [], _recovered_from: backup };
    }
    return this._store;
  }

  _loadIndex() {
    const ip = INDEX_PATH();
    try {
      if (fs.existsSync(ip)) {
        this._index = JSON.parse(fs.readFileSync(ip, 'utf-8'));
      } else {
        this._index = { version: 1, tags: {}, agents: {}, types: {} };
      }
    } catch {
      this._index = { version: 1, tags: {}, agents: {}, types: {} };
    }
    return this._index;
  }

  _saveStore() {
    const sp = STORE_PATH();
    fs.writeFileSync(sp, JSON.stringify(this._store, null, 2), 'utf-8');
  }

  _saveIndex() {
    const ip = INDEX_PATH();
    fs.writeFileSync(ip, JSON.stringify(this._index, null, 2), 'utf-8');
  }

  _rebuildIndex() {
    const index = { version: 1, tags: {}, agents: {}, types: {} };
    for (const entry of this._store.entries) {
      // Tags
      for (const tag of entry.tags || []) {
        if (!index.tags[tag]) index.tags[tag] = [];
        index.tags[tag].push(entry.id);
      }
      // Agent
      if (entry.agent_id) {
        if (!index.agents[entry.agent_id]) index.agents[entry.agent_id] = [];
        index.agents[entry.agent_id].push(entry.id);
      }
      // Type
      if (entry.type) {
        if (!index.types[entry.type]) index.types[entry.type] = [];
        index.types[entry.type].push(entry.id);
      }
    }
    this._index = index;
    this._saveIndex();
  }

  // ── Validation ──

  _validateWrite(write) {
    assert(write.agent_id, 'agent_id is required');
    assert(write.content, 'content is required');
    assert(typeof write.content === 'string', 'content must be a string');
    if (write.type) {
      assert(
        this.config.VALID_TYPES.includes(write.type),
        `Invalid type "${write.type}". Valid types: ${this.config.VALID_TYPES.join(', ')}`
      );
    }
    // Sanity check: don't store secrets
    const secretPatterns = [
      /PRIVATE_KEY/i, /-----BEGIN.*PRIVATE KEY-----/,
      /ghp_[a-zA-Z0-9]{36}/, /sk-[a-zA-Z0-9]{32,}/,
      /AKIA[0-9A-Z]{16}/
    ];
    for (const pat of secretPatterns) {
      if (pat.test(write.content)) {
        throw new Error(`[Grid] Write rejected: content appears to contain a secret (matched: ${pat})`);
      }
    }
  }

  // ── Write ──

  async write(write = {}) {
    this._validateWrite(write);
    this._loadStore();

    const type = write.type || 'observation';
    const ttl = write.ttl_seconds || this.config.DEFAULT_TTLS[type] || 86400;
    const entry = {
      id: generateId(),
      session_id: write.session_id || '',
      agent_id: write.agent_id,
      type: type,
      tags: write.tags || [],
      content: write.content.trim(),
      ttl_seconds: ttl,
      created_at: now(),
      expires_at: new Date(Date.now() + (ttl * 1000)).toISOString(),
      parent_entry: write.parent_entry || null,
      last_read_at: null
    };

    this._store.entries.push(entry);
    this._saveStore();

    // Update index
    this._loadIndex();
    for (const tag of entry.tags) {
      if (!this._index.tags[tag]) this._index.tags[tag] = [];
      this._index.tags[tag].push(entry.id);
    }
    if (!this._index.agents[entry.agent_id]) this._index.agents[entry.agent_id] = [];
    this._index.agents[entry.agent_id].push(entry.id);
    if (!this._index.types[type]) this._index.types[type] = [];
    this._index.types[type].push(entry.id);
    this._saveIndex();

    // Auto-prune if store is large
    const storeSize = Buffer.byteLength(JSON.stringify(this._store)) / (1024 * 1024);
    if (storeSize > this.config.COMPRESSION_THRESHOLD_MB) {
      await this.prune();
    }

    return {
      entry_id: entry.id,
      agent_id: entry.agent_id,
      type: entry.type,
      tags: entry.tags,
      created_at: entry.created_at,
      ttl_seconds: entry.ttl_seconds,
      expires_at: entry.expires_at,
      store_entries_count: this._store.entries.length
    };
  }

  // ── Read ──

  async read(query = {}) {
    this._loadStore();

    const maxResults = Math.min(
      query.max || this.config.DEFAULT_MAX_RESULTS,
      this.config.ABSOLUTE_MAX_RESULTS
    );
    const tags = query.tags || [];
    const agents = query.agents || [];
    const types = query.types || [];
    const type = query.type || null; // single type shorthand
    const since = query.since || null; // ISO timestamp
    const tagMode = query.tagMode || 'OR'; // AND | OR
    const parent_entry = query.parent_entry || null;

    // Filter expired
    const nowTs = now();
    let entries = this._store.entries.filter(e => e.expires_at >= nowTs);

    // Filter by parent
    if (parent_entry) {
      entries = entries.filter(e => e.parent_entry === parent_entry || e.id === parent_entry);
    }

    // Filter by tags
    if (tags.length > 0) {
      entries = entries.filter(e => {
        const eTags = new Set(e.tags || []);
        if (tagMode === 'AND') {
          return tags.every(t => eTags.has(t));
        } else {
          return tags.some(t => eTags.has(t));
        }
      });
    }

    // Filter by agents
    if (agents.length > 0) {
      const agentSet = new Set(agents);
      entries = entries.filter(e => agentSet.has(e.agent_id));
    }

    // Filter by type
    if (type) {
      entries = entries.filter(e => e.type === type);
    } else if (types.length > 0) {
      const typeSet = new Set(types);
      entries = entries.filter(e => typeSet.has(e.type));
    }

    // Filter by time
    if (since) {
      entries = entries.filter(e => e.created_at >= since);
    }
    if (query.before) {
      entries = entries.filter(e => e.created_at <= query.before);
    }

    // Score and sort by relevance
    entries = this._scoreAndSort(entries, tags, agents, type || types);

    // Limit
    const results = entries.slice(0, maxResults);

    // Update last_read_at
    const nowIso = now();
    for (const entry of results) {
      entry.last_read_at = nowIso;
    }
    this._saveStore();

    const totalBefore = this._store.entries.length;
    const expiredCount = totalBefore - this._store.entries.filter(e => e.expires_at >= now()).length;

    return {
      entries: results.map(e => ({
        id: e.id,
        agent_id: e.agent_id,
        type: e.type,
        tags: e.tags,
        content: e.content,
        created_at: e.created_at,
        expires_at: e.expires_at,
        parent_entry: e.parent_entry
      })),
      query_meta: {
        total_before_filter: totalBefore,
        expired_filtered: expiredCount,
        returned: results.length,
        query: { tags, agents, types, since, tagMode, maxResults }
      }
    };
  }

  _scoreAndSort(entries, queryTags, queryAgents, queryTypes) {
    const nowTs = nowUnix();
    return entries.map(e => {
      let score = 0;

      // Tag match score
      if (queryTags.length > 0) {
        const eTags = new Set(e.tags || []);
        const matchCount = queryTags.filter(t => eTags.has(t)).length;
        score += matchCount * 10; // each matching tag = 10 points
      }

      // Type match score
      const qTypes = Array.isArray(queryTypes) ? queryTypes : [queryTypes];
      if (qTypes.length > 0 && qTypes.includes(e.type)) {
        score += 5;
      }

      // Agent match score
      if (queryAgents.length > 0 && queryAgents.includes(e.agent_id)) {
        score += 3;
      }

      // Recency bonus: entries created within last 30 minutes get +2, last 5 minutes get +5
      const ageSeconds = nowTs - new Date(e.created_at).getTime() / 1000;
      if (ageSeconds < 300) score += 5;
      else if (ageSeconds < 1800) score += 2;

      return { ...e, _score: score };
    })
    .sort((a, b) => b._score - a._score);
  }

  // ── Prune ──

  async prune() {
    this._loadStore();
    const before = this._store.entries.length;
    const nowTs = now();
    const alive = this._store.entries.filter(e => e.expires_at >= nowTs);
    const removed = before - alive.length;
    this._store.entries = alive;
    this._saveStore();

    // Check store size
    const storeSize = Buffer.byteLength(JSON.stringify(this._store)) / (1024 * 1024);
    if (storeSize > this.config.COMPRESSION_THRESHOLD_MB) {
      // Compress old entries: summarize by type+agent per day
      this._compress();
    }

    this._rebuildIndex();

    return {
      removed,
      remaining: alive.length,
      total_before: before,
      store_size_mb: Math.round(storeSize * 100) / 100,
      compressed: storeSize > this.config.COMPRESSION_THRESHOLD_MB
    };
  }

  _compress() {
    // Group entries by type + agent_id + date, keep only the most recent 3 per group
    const groups = {};
    for (const entry of this._store.entries) {
      const date = entry.created_at.slice(0, 10);
      const key = `${entry.type}:${entry.agent_id}:${date}`;
      if (!groups[key]) groups[key] = [];
      groups[key].push(entry);
    }
    const newEntries = [];
    for (const [key, group] of Object.entries(groups)) {
      // Sort by created_at descending, keep top 3
      group.sort((a, b) => b.created_at.localeCompare(a.created_at));
      newEntries.push(...group.slice(0, 3));
    }
    this._store.entries = newEntries;
  }

  // ── Context Injection ──

  async inject(contextHint = '') {
    this._loadStore();

    // Extract potential tags from the context hint
    const hintTags = this._extractTags(contextHint);

    // Query for relevant entries
    const result = await this.read({
      tags: hintTags,
      max: this.config.DEFAULT_MAX_RESULTS,
      tagMode: 'OR'
    });

    // If no tag matches, fall back to most recent entries
    let entries = result.entries;
    if (entries.length === 0) {
      const allAlive = this._store.entries
        .filter(e => e.expires_at >= now())
        .sort((a, b) => b.created_at.localeCompare(a.created_at))
        .slice(0, 5);
      entries = allAlive.map(e => ({
        id: e.id, agent_id: e.agent_id, type: e.type,
        tags: e.tags, content: e.content,
        created_at: e.created_at, expires_at: e.expires_at
      }));
    }

    // Build context block with size limit
    let block = '─── SHARED MEMORY GRID ───\n\n';
    block += `Recent entries (filtered: ${result.query_meta.returned} of ${result.query_meta.total_before_filter} total):\n\n`;

    for (const entry of entries) {
      const time = entry.created_at.slice(11, 16);
      const tags = (entry.tags || []).join(', ');
      const snippet = entry.content.length > 200
        ? entry.content.slice(0, 200) + '…'
        : entry.content;
      block += `[${entry.type}] ${time} — agent:${entry.agent_id}`;
      if (tags) block += ` — ${tags}`;
      block += `\n${snippet}\n\n`;
    }

    block += '─── END GRID ───';

    // Respect size limit
    const blockBytes = Buffer.byteLength(block, 'utf-8');
    if (blockBytes > this.config.MAX_INJECT_SIZE) {
      // Truncate from the end, preserving the header and footer
      const header = block.slice(0, 200); // keep header
      const footer = '\n\n─── END GRID ───';
      const maxBody = this.config.MAX_INJECT_SIZE - Buffer.byteLength(header + footer, 'utf-8');
      block = header + '\n\n[Content truncated due to size limit…]\n\n' + footer;
    }

    return { block, entry_count: entries.length, bytes: Buffer.byteLength(block, 'utf-8') };
  }

  _extractTags(text) {
    // Extract potential tags from natural language:
    // - Project names (project:X patterns in existing tags)
    // - Words that match existing tags
    if (!text) return [];

    this._loadIndex();
    const existingTags = Object.keys(this._index.tags || {});
    if (existingTags.length === 0) return [];

    const words = text.toLowerCase().split(/\s+/);
    const matched = existingTags.filter(tag => {
      const lowerTag = tag.toLowerCase();
      return words.some(w => lowerTag.includes(w) || w.includes(lowerTag));
    });

    return matched.slice(0, 5); // limit to 5 tag matches
  }

  // ── Forget ──

  async forget(entryId) {
    this._loadStore();
    const idx = this._store.entries.findIndex(e => e.id === entryId);
    if (idx === -1) {
      return { found: false, message: `Entry ${entryId} not found` };
    }
    const entry = this._store.entries.splice(idx, 1)[0];
    this._saveStore();
    this._rebuildIndex();
    return { found: true, entry_id: entry.id, type: entry.type, agent_id: entry.agent_id };
  }

  // ── Info ──

  async info() {
    this._loadStore();
    const entries = this._store.entries;
    const nowTs = now();

    // Stats by type
    const byType = {};
    for (const e of entries) {
      byType[e.type] = (byType[e.type] || 0) + 1;
    }

    // Stats by agent
    const byAgent = {};
    for (const e of entries) {
      byAgent[e.agent_id] = (byAgent[e.agent_id] || 0) + 1;
    }

    // Unique tags
    const allTags = new Set();
    for (const e of entries) {
      for (const t of e.tags || []) allTags.add(t);
    }

    const alive = entries.filter(e => e.expires_at >= nowTs);
    const expired = entries.length - alive.length;
    const storeSize = Buffer.byteLength(JSON.stringify(this._store)) / 1024;

    return {
      total_entries: entries.length,
      alive_entries: alive.length,
      expired_entries: expired,
      unique_agents: Object.keys(byAgent).length,
      unique_tags: allTags.size,
      store_size_kb: Math.round(storeSize * 10) / 10,
      by_type: byType,
      by_agent: byAgent,
      oldest_entry: entries.length > 0 ? entries[0].created_at : null,
      newest_entry: entries.length > 0 ? entries[entries.length - 1].created_at : null,
      store_version: this._store.version
    };
  }

  // ── Wipe (for testing) ──

  async wipe(confirm = false) {
    if (!confirm) {
      return { wiped: false, message: 'Confirmation required. Call wipe(true) to confirm.' };
    }
    this._store = { version: 1, created_at: now(), entries: [] };
    this._index = { version: 1, tags: {}, agents: {}, types: {} };
    this._saveStore();
    this._saveIndex();
    return { wiped: true, message: 'Shared memory grid cleared.' };
  }
}

// ─── CLI ──────────────────────────────────────────────────────────────────────

async function main() {
  const args = process.argv.slice(2);
  const command = args[0];

  if (!command) {
    console.log('Usage:');
    console.log('  node store.js write --agent <id> --type <type> --tags <a,b> --ttl <sec> --content "..."');
    console.log('  node store.js read [--tags a,b] [--agents a,b] [--type t] [--max N] [--since ISO]');
    console.log('  node store.js inject [--context "hint text"]');
    console.log('  node store.js prune');
    console.log('  node store.js forget --id <entry_id>');
    console.log('  node store.js info');
    console.log('  node store.js wipe');
    process.exit(0);
  }

  const parseArgs = () => {
    const map = {};
    for (let i = 1; i < args.length; i++) {
      if (args[i].startsWith('--')) {
        const key = args[i].slice(2);
        const val = args[i + 1] && !args[i + 1].startsWith('--') ? args[i + 1] : true;
        if (val !== true) i++;
        map[key] = val;
      }
    }
    return map;
  };

  const grid = new Grid();

  try {
    let result;

    switch (command) {
      case 'write': {
        const opts = parseArgs();
        result = await grid.write({
          agent_id: opts.agent || 'cli',
          type: opts.type || 'observation',
          tags: (opts.tags || '').split(',').filter(Boolean),
          ttl_seconds: parseInt(opts.ttl) || undefined,
          content: opts.content || '',
          session_id: opts.session || ''
        });
        break;
      }
      case 'read': {
        const opts = parseArgs();
        result = await grid.read({
          tags: (opts.tags || '').split(',').filter(Boolean),
          agents: (opts.agents || '').split(',').filter(Boolean),
          type: opts.type || null,
          types: (opts.types || '').split(',').filter(Boolean),
          max: parseInt(opts.max) || undefined,
          since: opts.since || null,
          tagMode: opts['tag-mode'] || 'OR'
        });
        break;
      }
      case 'inject': {
        const opts = parseArgs();
        result = await grid.inject(opts.context || '');
        break;
      }
      case 'prune':
        result = await grid.prune();
        break;
      case 'forget': {
        const opts = parseArgs();
        result = await grid.forget(opts.id);
        break;
      }
      case 'info':
        result = await grid.info();
        break;
      case 'wipe':
        result = await grid.wipe(true);
        break;
      default:
        console.error(`Unknown command: ${command}`);
        process.exit(1);
    }

    console.log(JSON.stringify(result, null, 2));
  } catch (err) {
    console.error(JSON.stringify({ error: err.message }, null, 2));
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}

module.exports = { Grid, CONFIG };

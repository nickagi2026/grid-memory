#!/usr/bin/env python3
"""
grid — Grid Memory CLI

Usage:
    grid init                 Initialize a new Grid store in current directory
    grid start                Start embedded server + proxy
    grid write                Write an entry (interactive or flags)
    grid query                Search entries (tag, semantic, or natural)
    grid info                 Show store statistics
    grid log                  Show recent activity
    grid prune                Remove expired entries
    grid patch                Auto-detect and patch framework
    grid ui                   Open dashboard URL
"""

import argparse
import json
import os
import sys
import textwrap
import time
from datetime import datetime
from typing import Dict, List, Optional, Any

# ─── ANSI Colors ────────────────────────────────────────────────────────────────

try:
    # Windows
    if sys.platform == "win32":
        import ctypes
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
except Exception:
    pass

_COLORS = {
    "reset": "\033[0m",
    "bold": "\033[1m",
    "dim": "\033[2m",
    "red": "\033[91m",
    "green": "\033[92m",
    "yellow": "\033[93m",
    "blue": "\033[94m",
    "magenta": "\033[95m",
    "cyan": "\033[96m",
    "white": "\033[97m",
    "bg_blue": "\033[44m",
    "bg_green": "\033[42m",
    "bg_yellow": "\033[43m",
}


def c(code: str, text: str) -> str:
    """Wrap text in ANSI color code."""
    c = _COLORS.get(code, "")
    return f"{c}{text}{_COLORS['reset']}" if c else text


# ─── Type Icons ─────────────────────────────────────────────────────────────────

_TYPE_ICONS = {
    "decision": "\U0001f9e9",   # 🧩
    "fact": "\U0001f4a1",       # 💡
    "handoff": "\U0001f500",    # 🔀
    "question": "\u2753",       # ❓
    "blocker": "\u26a0\ufe0f",  # ⚠️
    "observation": "\U0001f50d", # 🔍
    "task_status": "\U0001f4cb", # 📋
    "artifact_ref": "\U0001f4c4", # 📄
    "state_update": "\U0001f504", # 🔄
}

_TYPE_COLORS = {
    "decision": "magenta",
    "fact": "green",
    "handoff": "cyan",
    "question": "yellow",
    "blocker": "red",
    "observation": "blue",
    "task_status": "white",
    "artifact_ref": "dim",
    "state_update": "cyan",
}


# ─── Backend ────────────────────────────────────────────────────────────────────

def _get_grid(args=None):
    """Create LocalGrid from args or defaults."""
    from grid_memory.local_grid import LocalGrid
    store_dir = None
    if args and args.dir:
        store_dir = args.dir
    else:
        # Check for .grid.json in current directory
        local_config = os.path.join(os.getcwd(), ".grid.json")
        if os.path.exists(local_config):
            with open(local_config) as f:
                cfg = json.load(f)
                store_dir = cfg.get("store_dir")
    return LocalGrid(store_dir=store_dir)


def _get_grid_with_embeddings(args=None):
    """Create LocalGrid with embedding engine if configured."""
    from grid_memory.local_grid import LocalGrid
    grid = _get_grid(args)

    # Try to configure embeddings
    api_key = os.environ.get("GRID_EMBEDDING_API_KEY")
    if api_key:
        try:
            from grid_memory.embeddings import EmbeddingEngine
            ee = EmbeddingEngine(
                provider="openai",
                api_key=api_key,
            )
            # Inject into grid
            grid._embedding_engine = ee
        except Exception as e:
            print(f"  {c('yellow', '⚠ Embeddings configured but failed:')} {e}", file=sys.stderr)

    return grid


# ─── Output Formatters ──────────────────────────────────────────────────────────


def _format_entry(entry: Dict, verbose: bool = False) -> str:
    """Format a single entry for human-readable output."""
    etype = entry.get("type", "observation")
    icon = _TYPE_ICONS.get(etype, "\U0001f4ac")
    color = _TYPE_COLORS.get(etype, "white")
    created = entry.get("created_at", "")[11:19]  # HH:MM:SS
    agent = entry.get("agent_id", "?")
    content = entry.get("content", "")
    tags = entry.get("tags", [])
    has_emb = entry.get("has_embedding", False)
    score = entry.get("relevance_score")

    lines = [f"  {icon} {c(color, f'[{etype}]')} {c('dim', created)} — {c('cyan', agent)}"]
    if score is not None:
        lines[0] += f" {c('yellow', f'({score:.1f})')}"
    if has_emb:
        lines[0] += f" {c('green', '\u2728')}"  # ✨

    # Content preview
    if verbose:
        lines.append(f"    {content}")
    else:
        preview = content[:120].replace("\n", " ")
        if len(content) > 120:
            preview += "..."
        lines.append(f"    {preview}")

    if tags:
        tag_str = ", ".join(c("dim", f"#{t}") for t in tags)
        lines.append(f"    {tag_str}")

    return "\n".join(lines)


def _format_info(info: Dict) -> str:
    """Format store info as a nice table."""
    lines = [
        "",
        f"  {c('bold', 'Grid Store Summary')}",
        f"  {'─' * 40}",
        f"  {c('green', '\u25cf')} Total entries: {c('bold', str(info['total_entries']))}",
        f"  {c('green', '\u25cf')} Alive:         {c('bold', str(info['alive_entries']))}",
        f"  {c('red', '\u25cf')} Expired:       {c('dim', str(info['expired_entries']))}",
        f"  {c('blue', '\u25cf')} Unique agents: {c('bold', str(info['unique_agents']))}",
        f"  {c('yellow', '\u25cf')} Unique tags:   {c('bold', str(info['unique_tags']))}",
        f"  {c('dim', '\u25cf')} Store size:    {c('bold', str(info['store_size_kb']))} KB",
    ]
    if info.get("oldest_entry"):
        lines.append(
            f"  {c('dim', '\u25cf')} Range:         "
            f"{info['oldest_entry'][:10]} \u2192 {info['newest_entry'][:10]}"
        )

    # By type breakdown
    if info.get("by_type"):
        lines.extend([
            "",
            f"  {c('bold', 'By Type')}",
        ])
        for etype, count in sorted(info["by_type"].items(), key=lambda x: -x[1]):
            icon = _TYPE_ICONS.get(etype, "\U0001f4ac")
            color_code = _TYPE_COLORS.get(etype, "white")
            lines.append(f"    {icon} {c(color_code, etype)}: {count}")

    # By agent breakdown
    if info.get("by_agent"):
        lines.extend([
            "",
            f"  {c('bold', 'By Agent')}",
        ])
        for agent, count in sorted(info["by_agent"].items(), key=lambda x: -x[1]):
            lines.append(f"    {c('cyan', agent)}: {count}")

    return "\n".join(lines)


# ─── Commands ───────────────────────────────────────────────────────────────────


def cmd_init(args):
    """Initialize a new Grid store in the current or specified directory."""
    from grid_memory.local_grid import LocalGrid

    store_dir = args.dir or os.path.join(os.getcwd(), ".grid")
    os.makedirs(store_dir, exist_ok=True)
    grid = LocalGrid(store_dir=store_dir)

    # Create .grid.json config
    config_path = os.path.join(os.getcwd(), ".grid.json")
    config = {
        "store_dir": store_dir,
        "created_at": datetime.utcnow().isoformat() + "Z",
        "version": 1,
    }
    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)

    print(f"  {c('green', '\u2713')} Grid initialized at {c('bold', store_dir)}")
    print(f"  {c('dim', '.grid.json config created')}")


def cmd_start(args):
    """Start the embedded server + OpenAI proxy."""
    port = args.port or int(os.environ.get("PORT", "8080"))
    host = args.host or os.environ.get("HOST", "0.0.0.0")

    print(f"  {c('green', '\u25b6')} Starting Grid server on {c('bold', f'http://{host}:{port}')}")
    print(f"  {c('green', '\u25b6')} OpenAI-compatible endpoint: {c('bold', f'http://{host}:{port}/v1')}")
    print(f"  {c('dim', 'Dashboard: http://localhost:' + str(port) + '/dashboard/index.html')}")
    print()

    # Import and start server
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from grid_memory.openai_server import run_server

    os.environ["PORT"] = str(port)
    os.environ["HOST"] = host
    run_server()


def cmd_write(args):
    """Write an entry to the Grid."""
    grid = _get_grid(args)

    content = args.content
    if not content:
        content = input("  Content: ")

    etype = args.type or "observation"
    agent = args.agent or "cli"
    tags = args.tags.split(",") if args.tags else []

    result = grid.write(
        agent_id=agent,
        type=etype,
        content=content,
        tags=tags,
        ttl_seconds=args.ttl,
    )

    print(f"  {c('green', '\u2713')} Written {c('bold', result['entry_id'])}")
    print(f"    Type: {result['type']}  Agent: {c('cyan', result['agent_id'])}")
    if tags:
        print(f"    Tags: {', '.join(c('dim', f'#{t}') for t in tags)}")


def cmd_query(args):
    """Query the Grid."""
    grid = _get_grid_with_embeddings(args)

    tags = args.tags.split(",") if args.tags else []
    agents = args.agents.split(",") if args.agents else []
    query_type = args.type
    max_results = args.max or 20

    if args.natural:
        # Natural language query — use semantic search
        result = grid.query(
            semantic=args.natural,
            max=max_results,
            semantic_weight=min(args.weight or 0.7, 1.0),
        )

        meta = result["query_meta"]
        if meta.get("semantic_available"):
            print(f"\n  {c('bold', 'Semantic Search')}")
            print(f"  Query: \"{args.natural}\"")
            print(f"  {c('dim', 'Searching by meaning...')}\n")
        else:
            print(f"\n  {c('yellow', '⚠ No embedding engine configured')}")
            print(f"  {c('dim', 'Set GRID_EMBEDDING_API_KEY for semantic search')}\n")
    else:
        # Tag-based query
        result = grid.query(
            tags=tags,
            agents=agents,
            type=query_type,
            max=max_results,
        )

    entries = result.get("entries", [])
    meta = result.get("query_meta", {})

    if not entries:
        print(f"\n  {c('yellow', 'No matching entries found')}")
        return

    total_filtered = meta.get("total_before_filter", "?")
    print(f"\n  {c('bold', f'Found {len(entries)} entries')} "
          f"{c('dim', f'(filtered from {total_filtered})')}")

    for entry in entries:
        print()
        print(_format_entry(entry, verbose=args.verbose))

    print()


def cmd_info(args):
    """Show store statistics."""
    grid = _get_grid(args)
    info = grid.info()
    print(_format_info(info))
    print()


def cmd_log(args):
    """Show recent activity."""
    grid = _get_grid(args)
    max_entries = args.max or 20

    result = grid.query(max=max_entries)
    entries = result.get("entries", [])

    if not entries:
        print(f"\n  {c('yellow', 'No entries yet')}")
        return

    print(f"\n  {c('bold', 'Recent Activity')}\n")
    for entry in entries:
        print(_format_entry(entry, verbose=args.verbose))
        print()


def cmd_prune(args):
    """Remove expired entries."""
    grid = _get_grid(args)
    result = grid.prune()
    pruned = result.get("removed", 0)
    print(f"\n  {c('green', f'\u2713 Pruned {pruned} expired entries')}")
    remaining_count = result.get("remaining", 0)
    print(f"  {c('dim', f'{remaining_count} entries remaining')}\n")


def cmd_patch(args):
    """Auto-detect and patch the running agent framework."""
    # Detect framework
    framework = None
    framework_detected = False

    try:
        import autogen
        framework = "AutoGen"
        framework_detected = True
    except ImportError:
        pass

    if not framework_detected:
        try:
            import crewai
            framework = "CrewAI"
            framework_detected = True
        except ImportError:
            pass

    if not framework_detected:
        try:
            from langgraph.graph import StateGraph
            framework = "LangGraph"
            framework_detected = True
        except ImportError:
            pass

    if not framework_detected:
        try:
            import langchain
            framework = "LangChain"
            framework_detected = True
        except ImportError:
            pass

    if not framework_detected:
        print(f"\n  {c('yellow', 'No supported framework detected.')}")
        print(f"  {c('dim', 'Install one: pip install pyautogen crewai langgraph langchain')}\n")
        return

    print(f"\n  {c('green', f'\u2713 Detected: {framework}')}")

    from grid_memory.local_grid import LocalGrid
    grid = LocalGrid()

    if framework == "AutoGen":
        import autogen
        from grid_memory import AutoGenGridPlugin
        plugin = AutoGenGridPlugin(agent_id=args.agent or "patched-agent")
        print(f"  {c('dim', 'Usage:')}")
        print(f"    agent = autogen.AssistantAgent(name='agent', llm_config=llm_config)")
        print(f"    agent = plugin.wrap(agent)")

    elif framework == "CrewAI":
        from grid_memory import CrewAITool
        tool = CrewAITool(agent_id=args.agent or "patched-agent")
        print(f"  {c('dim', 'Usage:')}")
        print(f"    tool = CrewAITool()")
        print(f"    agent = Agent(name='agent', tools=[tool.query_tool(), tool.write_tool()])")

    elif framework == "LangGraph":
        from grid_memory import langgraph_grid_node
        print(f"  {c('dim', 'Usage:')}")
        print(f"    inject = langgraph_grid_node()")
        print(f"    graph.add_node('grid_inject', inject)")

    elif framework == "LangChain":
        print(f"  {c('dim', 'Usage:')}")
        print(f"    # Set OpenAI-compatible base_url on your LLM:")
        print(f"    llm = ChatOpenAI(base_url='http://localhost:8080/v1', model='gpt-4o')")

    print(f"\n  {c('green', f'Ready to patch {framework} agents with Grid memory.')}")
    print()


def cmd_curate(args):
    """Run one curation pass on the Grid."""
    from grid_memory.curator import GridCurator
    grid = _get_grid(args)
    curator = GridCurator(grid=grid)
    report = curator.curate()

    print(f"\n  {c('bold', 'Curation Report')}")
    print(f"  {'─' * 40}")
    print(f"  {c('green', '\u2713')} Archived:         {c('bold', str(report['archived']))}")
    print(f"  {c('green', '\u2713')} Merged groups:    {c('bold', str(len(report['merged'])))}")
    for merge in report['merged']:
        print(f"    {c('dim', f"survivor: {merge['survivor'][:24]}...")}")
        for deleted in merge['deleted']:
            print(f"    {c('dim', f'  \u2717 deleted: {deleted[:24]}...')}")
    print(f"  {c('green', '\u2713')} Summaries written: {c('bold', str(report['summaries_written']))}")
    print(f"  {c('green', '\u2713')} Contradictions:   {c('bold', str(report['contradictions_flagged']))}")
    print(f"  {c('green', '\u2713')} Tags suggested:   {c('bold', str(report['tags_suggested']))}")
    print(f"  {c('dim', f'Archived total: {curator.archive_count()}')}")
    print()


def cmd_ui(args):
    """Open the dashboard URL."""
    port = args.port or "8080"
    url = f"http://localhost:{port}/dashboard/index.html"
    print(f"\n  {c('green', '\u25b6')} Dashboard: {c('bold', url)}\n")

    # Try to open browser
    import webbrowser
    try:
        webbrowser.open(url)
        print(f"  {c('dim', 'Browser opened.')}")
    except Exception:
        print(f"  {c('yellow', 'Open manually:')} {url}\n")


# ─── Main Parser ────────────────────────────────────────────────────────────────


def main():
    parser = argparse.ArgumentParser(
        description="Grid Memory — shared persistent memory for multi-agent teams",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""\
            Examples:
              grid init
              grid write --agent architect --type decision --content "Use PostgreSQL" --tags database
              grid query --natural "what database do we use?"
              grid query --tags database --verbose
              grid info
              grid start
              grid ui
              grid patch
              grid curate
        """),
    )
    parser.add_argument("--dir", help="Grid store directory")
    parser.add_argument("--version", action="store_true", help="Show version")

    sub = parser.add_subparsers(dest="command")

    # init
    p_init = sub.add_parser("init", help="Initialize a Grid store")
    p_init.add_argument("--dir", help="Store directory (default: ./.grid)")

    # start
    p_start = sub.add_parser("start", help="Start the embedded server and proxy")
    p_start.add_argument("--port", type=int, help="Port (default: 8080)")
    p_start.add_argument("--host", default="0.0.0.0", help="Host (default: 0.0.0.0)")

    # write
    p_write = sub.add_parser("write", help="Write an entry")
    p_write.add_argument("--agent", default="cli", help="Agent identifier")
    p_write.add_argument("--type", default="observation",
                        choices=["fact", "decision", "handoff", "observation",
                                 "question", "blocker", "task_status", "artifact_ref"])
    p_write.add_argument("--tags", help="Comma-separated tags")
    p_write.add_argument("--ttl", type=int, help="TTL in seconds")
    p_write.add_argument("content", nargs="?", help="Entry content")

    # query
    p_query = sub.add_parser("query", help="Search entries")
    p_query.add_argument("--tags", help="Comma-separated tags to filter")
    p_query.add_argument("--agents", help="Comma-separated agent IDs")
    p_query.add_argument("--type", help="Filter by entry type")
    p_query.add_argument("--natural", help="Natural language query (semantic search)")
    p_query.add_argument("--weight", type=float, default=0.7,
                        help="Semantic weight 0-1 (default: 0.7)")
    p_query.add_argument("--max", type=int, default=20, help="Maximum results")
    p_query.add_argument("--verbose", "-v", action="store_true", help="Show full content")

    # info
    p_info = sub.add_parser("info", help="Show store statistics")

    # log
    p_log = sub.add_parser("log", help="Show recent activity")
    p_log.add_argument("--max", type=int, default=20, help="Number of entries")
    p_log.add_argument("--verbose", "-v", action="store_true", help="Show full content")

    # prune
    p_prune = sub.add_parser("prune", help="Remove expired entries")

    # patch
    p_patch = sub.add_parser("patch", help="Auto-detect and patch framework")
    p_patch.add_argument("--agent", help="Agent name for patching")

    # ui
    p_ui = sub.add_parser("ui", help="Open dashboard in browser")
    p_ui.add_argument("--port", type=int, help="Grid server port")

    # curate
    p_curate = sub.add_parser("curate", help="Run one curation pass (archive, dedup, summarize, flag, suggest)")
    p_curate.add_argument("--dir", help="Grid store directory")
    p_curate.add_argument("--daemon", action="store_true", help="Run continuously in background")

    # tier (sub-commands handled in cmd_tier)
    p_tier = sub.add_parser("tier", help="Memory tier operations (use: tier list|promote|scan)")
    p_tier.add_argument("tier_command", nargs="?", choices=["list", "promote", "scan"], help="Sub-command")
    p_tier.add_argument("entry_id", nargs="?", help="Entry ID (for promote)")
    p_tier.add_argument("tier", nargs="?", choices=["project", "organization"], help="Target tier (for promote)")
    p_tier.add_argument("--dry-run", action="store_true", help="Preview promotions without acting")
    p_tier.add_argument("--dir", help="Store directory")

    # analyze
    p_analyze = sub.add_parser("analyze", help="Run pattern analysis on the Grid")
    p_analyze.add_argument("--dir", help="Store directory")

    # insights
    p_insights = sub.add_parser("insights", help="Get ranked insights from the Grid")
    p_insights.add_argument("--min", type=float, default=0.3, help="Minimum confidence (0-1)")
    p_insights.add_argument("--dir", help="Store directory")

    # radar
    p_radar = sub.add_parser("radar", help="AI Opportunity Radar — find automation opportunities with $ value")
    p_radar.add_argument("--days", type=int, default=90, help="Analysis window in days")
    p_radar.add_argument("--min-confidence", type=float, default=0.3, help="Minimum confidence (0-1)")
    p_radar.add_argument("--min-value", type=float, default=500, help="Minimum annual value in $")
    p_radar.add_argument("--dir", help="Store directory")

    # export
    p_export = sub.add_parser("export", help="Export entries as JSON")
    p_export.add_argument("--output", "-o", help="Output file path (default: stdout)")
    p_export.add_argument("--compact", action="store_true", help="Minified JSON")

    # import
    p_import = sub.add_parser("import", help="Import entries from JSON")
    p_import.add_argument("--file", "-f", help="JSON file path")
    p_import.add_argument("--data", "-d", help="JSON string")
    p_import.add_argument("--replace", action="store_true", help="Replace existing store")
    p_import.add_argument("--agent", help="Override agent_id for all entries")
    p_import.add_argument("--tag-prefix", help="Prefix for all imported tags")

    # ask
    p_ask = sub.add_parser("ask", help="Ask a natural language question about the Grid")
    p_ask.add_argument("question", help="Your question")

    args = parser.parse_args()

    if args.version:
        print("grid-memory v1.1.0")
        return

    if not args.command:
        parser.print_help()
        return

    # Route commands
    command_map = {
        "init": cmd_init,
        "start": cmd_start,
        "write": cmd_write,
        "query": cmd_query,
        "info": cmd_info,
        "log": cmd_log,
        "prune": cmd_prune,
        "patch": cmd_patch,
        "ui": cmd_ui,
        "export": cmd_export,
        "import": cmd_import,
        "ask": cmd_ask,
        "curate": cmd_curate,
        "tier": cmd_tier,
        "analyze": cmd_analyze,
        "insights": cmd_insights,
    }

    cmd_fn = command_map.get(args.command)
    if cmd_fn:
        cmd_fn(args)


if __name__ == "__main__":
    main()

# ── New Commands ──


def cmd_export(args):
    """Export all entries as JSON."""
    grid = _get_grid(args)
    result = grid.export_json(output_path=args.output, pretty=not args.compact)
    if args.output:
        print(f"  {c('green', '\u2713')} Exported to {c('bold', result)}")
        print(f"  {c('dim', f'Use: grid import --file {result}')}")
    else:
        print(result)


def cmd_import(args):
    """Import entries from JSON."""
    grid = _get_grid(args)
    source = args.file or args.data
    if not source:
        print(f"  {c('red', '\u2717')} Provide --file or --data")
        return

    result = grid.import_json(
        json_input=source,
        merge=not args.replace,
        agent_override=args.agent,
        tag_prefix=args.tag_prefix,
    )
    print(f"  {c('green', '\u2713')} Imported {result['imported']} entries")
    if result['skipped']:
        skipped_count = result.get("skipped", 0)
        print(f"  {c('yellow', f'\u26a0 {skipped_count} skipped')}")
    if result['errors']:
        for err in result['errors'][:3]:
            print(f"  {c('red', f'  \u2717 {err}')}")


def cmd_ask(args):
    """Ask a natural language question about the Grid."""
    from grid_memory.local_grid import LocalGrid
    grid = _get_grid(args)

    # Get Grid context
    context = grid.inject(context=args.question)
    block = context.get("block", "")

    if not context.get("entry_count", 0):
        print(f"\n  {c('yellow', 'No entries in the Grid yet.')}")
        print(f"  {c('dim', 'Write some data first: grid write --content \"...\"')}\n")
        return

    # Try to use an LLM via the OpenAI proxy
    api_key = os.environ.get("GRID_UPSTREAM_API_KEY")
    upstream_url = os.environ.get("GRID_UPSTREAM_URL", "https://api.openai.com")

    if api_key:
        print(f"\n  {c('green', '\u25b6 Thinking...')}")

        import urllib.request
        body = json.dumps({
            "model": os.environ.get("GRID_UPSTREAM_MODEL", "gpt-4o-mini"),
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "You are a Grid Memory analyst. You have access to shared agent memory. "
                        "Answer questions based ONLY on the context provided.\n\n"
                        f"--- SHARED MEMORY GRID ---\n{block}\n--- END GRID ---"
                    ),
                },
                {"role": "user", "content": args.question},
            ],
            "temperature": 0.3,
            "max_tokens": 1000,
        }).encode()

        req = urllib.request.Request(
            f"{upstream_url}/v1/chat/completions",
            data=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {api_key}",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read())
                answer = data["choices"][0]["message"]["content"]
                print(f"\n  {answer}\n")
        except Exception as e:
            print(f"\n  {c('red', f'\u2717 LLM error: {e}')}\n")
            print(f"  {c('dim', 'Falling back to context-only mode...')}\n")
            print(f"  {block}\n")
    else:
        # No LLM — just show the context
        print(f"\n  {c('yellow', 'No GRID_UPSTREAM_API_KEY configured.')}")
        print(f"  {c('dim', 'Showing raw Grid context instead:')}\n")
        print(f"  {block}\n")
        print(f"  {c('dim', 'Set GRID_UPSTREAM_API_KEY to get natural language answers.')}\n")


# ── Integrate into main parser ──

# These will be merged into the main() function below
# The commands are registered in the parser build

def cmd_curate(args):
    """Run one curation pass."""
    from grid_memory.curator import GridCurator
    grid = _get_grid(args)
    curator = GridCurator(grid=grid)
    print(f"\n  {c('green', '\u25b6 Running curation...')}\n")
    report = curator.curate()
    print(f"  {c('green', '\u2713 Curated')}")
    print(f"    Archived:              {report.get('archived', 0)}")
    print(f"    Merged:                {sum(len(m.get('deleted', [])) for m in report.get('merged', []))} entries into {len(report.get('merged', []))} survivors")
    print(f"    Summaries written:     {report.get('summaries_written', 0)}")
    print(f"    Contradictions flagged: {report.get('contradictions_flagged', 0)}")
    print(f"    Tags suggested:        {report.get('tags_suggested', 0)}")
    print()

def cmd_tier(args):
    """Memory tier operations."""
    from grid_memory.local_grid import LocalGrid
    from grid_memory.tiers import PromotionEngine

    grid = _get_grid(args)
    engine = PromotionEngine(grid)

    if args.tier_command == "list":
        dist = engine.get_tier_distribution()
        print(f"\n  {c('bold', 'Memory Tier Distribution')}")
        print(f"  {'─' * 40}")
        print(f"  {c('yellow', '\u26a1')} Working:       {c('bold', str(dist.get('working', 0)))}")
        print(f"  {c('cyan', '\U0001f4e6')} Project:       {c('bold', str(dist.get('project', 0)))}")
        print(f"  {c('green', '\U0001f3f0')} Organization:  {c('bold', str(dist.get('organization', 0)))}")
        total = sum(dist.values())
        print(f"  {c('dim', f'Total: {total}')}\n")

    elif args.tier_command == "promote":
        result = engine.promote(args.entry_id, args.tier)
        if result["success"]:
            print(f"\n  {c('green', '\u2713')} Promoted {c('bold', args.entry_id[:16])}... "
                  f"{c('yellow', result['from_tier'])} \u2192 {c('cyan', result['to_tier'])}\n")
        else:
            print(f"\n  {c('red', f'\u2717 {result[\"reason\"]}')}\n")

    elif args.tier_command == "scan":
        result = engine.scan_and_promote(dry_run=args.dry_run)
        wp = result.get("working_to_project", [])
        po = result.get("project_to_organization", [])

        if args.dry_run:
            print(f"\n  {c('bold', 'Dry Run — Would Promote:')}")
        else:
            print(f"\n  {c('green', '\u2713 Scanned and Promoted:')}")
        print(f"  {'─' * 40}")
        print(f"  \u26a1 Working \u2192 \U0001f4e6 Project:   {c('bold', str(len(wp)))}")
        for item in wp:
            print(f"    {c('dim', item['id'][:16])} {item['content_preview'][:50]}"
                  f"  {c('yellow', ', '.join(item.get('reasons', [])))}")
        print(f"  \U0001f4e6 Project \u2192 \U0001f3f0 Org:      {c('bold', str(len(po)))}")
        for item in po:
            print(f"    {c('dim', item['id'][:16])} {item['content_preview'][:50]}"
                  f"  {c('yellow', ', '.join(item.get('reasons', [])))}")
        if not wp and not po:
            print(f"  {c('dim', 'No eligible entries found.')}")
        print()


def cmd_analyze(args):
    """Run pattern analysis on the Grid."""
    from grid_memory.learning import LearningEngine
    grid = _get_grid(args)
    engine = LearningEngine(grid)

    print(f"\n  {c('green', '\u25b6 Analyzing Grid patterns...')}\n")
    results = engine.analyze()

    # Blockers
    blockers = results.get("recurring_blockers", [])
    if blockers:
        print(f"  {c('red', f'\u26a0 Recurring Blockers ({len(blockers)})')}")
        for b in blockers[:5]:
            print(f"    \u2022 {b['pattern']} ({c('bold', str(b['count']))}x, {b['agents_involved']} agents)")
        print()

    # Decisions
    decisions = results.get("frequent_decisions", [])
    if decisions:
        print(f"  {c('magenta', f'\U0001f9e9 Frequent Decisions ({len(decisions)})')}")
        for d in decisions[:5]:
            print(f"    \u2022 {d['topic']} ({c('bold', str(d['count']))}x, {d['agents_involved']} agents)")
        print()

    # Workflows
    workflows = results.get("workflow_patterns", [])
    if workflows:
        print(f"  {c('cyan', f'\U0001f500 Workflow Patterns ({len(workflows)})')}")
        for w in workflows[:5]:
            print(f"    \u2022 {w['from_agent']} \u2192 {w['to_agent']} "
                  f"({c('bold', str(w['handoff_count']))} handoffs)")
        print()

    # Agents
    agents = results.get("agent_trends", [])
    if agents:
        print(f"  {c('blue', f'\U0001f465 Agent Activity ({len(agents)} agents)')}")
        for a in agents[:5]:
            print(f"    \u2022 {c('cyan', a['agent'])}: {a['total_entries']} entries "
                  f"({c('dim', a['most_common_type'])})")
        print()

    # Top tags
    tags = results.get("top_tags", [])
    if tags:
        print(f"  {c('yellow', f'\U0001f516 Top Tags')}")
        print(f"    {', '.join(f'{c(\"green\", t[\"tag\"])} ({t[\"count\"]}x)' for t in tags[:10])}")
        print()

    # Gaps
    gaps = results.get("knowledge_gaps", [])
    if gaps:
        print(f"  {c('yellow', f'\u2753 Knowledge Gaps ({len(gaps)})')}")
        for g in gaps[:3]:
            print(f"    \u2022 {g['question'][:80]}")
            print(f"      {c('dim', f'unanswered tags: {\", \".join(g[\"unanswered_tags\"])}')}")
        print()

    print(f"  {c('dim', f'Analyzed {results[\"total_entries_analyzed\"]} entries')}\n")


def cmd_insights(args):
    """Get ranked insights from the Grid."""
    from grid_memory.learning import LearningEngine
    grid = _get_grid(args)
    engine = LearningEngine(grid)

    print(f"\n  {c('green', '\u25b6 Generating insights...')}\n")
    insights = engine.get_insights(min_confidence=getattr(args, 'min', 0.3))

    if not insights:
        print(f"  {c('yellow', 'Not enough data for insights yet. Add more entries.')}\n")
        return

    print(f"  {c('bold', f'{len(insights)} Insights Found')}")
    print(f"  {'─' * 40}")

    for ins in insights:
        icon = {"recurring_blocker": "\u26a0", "frequent_decision": "\U0001f9e9",
                 "workflow_pattern": "\U0001f500"}.get(ins["type"], "\U0001f4ac")
        confidence_bar = "\u2588" * int(ins["confidence"] * 10) + "\u2591" * (10 - int(ins["confidence"] * 10))
        print(f"  {icon} {ins['summary']}")
        print(f"    {c('dim', confidence_bar)} {c('yellow', f'{ins[\"confidence\"]:.0%} confidence')}")
        print()

    print()

def cmd_radar(args):
    """Run the AI Opportunity Radar scan."""
    from grid_memory.opportunity_radar import OpportunityRadar
    grid = _get_grid(args)
    radar = OpportunityRadar(
        grid,
        window_days=args.days or 90,
        min_confidence=args.min_confidence or 0.3,
        min_annual_value=args.min_value or 500,
    )

    data = radar.scan()
    print(radar.report(format="text"))

    # Write radar results to Grid
    if data.get("opportunities"):
        grid.fact(
            f"Opportunity Radar: ${data['total_annual_value']:,.0f}/yr in "
            f"{data['total_opportunities']} opportunities. "
            f"Top: {data['top_opportunity']}",
            tags=["opportunity-radar", "scan"],
            agent_id="opportunity-radar",
        )
